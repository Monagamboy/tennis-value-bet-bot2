import os
from dotenv import load_dotenv

load_dotenv()

def main():
    print("Bot de Value Bet Tennis en cours...")
    # Simulation d'une value bet trouvée
    print("Match : Nadal vs Djokovic")
    print("Value Bet détectée : Victoire Nadal @2.10 (valeur estimée : 1.90)")

if __name__ == "__main__":
    main()
